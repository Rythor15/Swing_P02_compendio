/**
 * PanelTituloDialogo.java
 * 16 nov 2024 17:11:16
 * @author Rubén Fernández Contreras
 */
package swing_c_p2_FernandezContrerasRuben;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

// TODO: Auto-generated Javadoc
/**
 * The Class PanelTituloDialogo.
 */
public class PanelTituloDialogo extends JPanel{

	/** The titulo. */
	JLabel titulo = new JLabel("Hotel Pochita");
		
	/**
	 * Instantiates a new panel titulo dialogo.
	 */
	public PanelTituloDialogo() {
		titulo.setFont(new Font("Arial", Font.BOLD, 30));
		this.setBackground(new Color(0,255,255));
		titulo.setForeground(new Color(122,169,250));
		this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		this.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.add(titulo);
	}
	
}

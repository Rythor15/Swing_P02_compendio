/**
 * VentanaDialogo.java
 * 16 nov 2024 16:37:33
 * @author Rubén Fernández Contreras
 */
package swing_c_p2_FernandezContrerasRuben;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JPanel;

// TODO: Auto-generated Javadoc
/**
 * The Class VentanaDialogo.
 */
public class VentanaDialogo extends JDialog{
	
	/** The t. */
	Toolkit t = Toolkit.getDefaultToolkit();
	
	/** The screen size. */
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	
	/** The img icon. */
	Image imgIcon;
	
	/** The ptd. */
	PanelTituloDialogo ptd = new PanelTituloDialogo();
	
	/** The pdp. */
	PanelDatosPersonales pdp = new PanelDatosPersonales();
	
	/** The pdh. */
	PanelDatosHabitacion pdh = new PanelDatosHabitacion();
	
	/** The pi. */
	PanelInformacion pi = new PanelInformacion();
	
	/** The v box. */
	Box vBox = Box.createVerticalBox();
	
	
	/**
	 * Instantiates a new ventana dialogo.
	 *
	 * @param ventanaPrincipal the ventana principal
	 * @param titulo the titulo
	 * @param modal the modal
	 */
	public VentanaDialogo(VentanaPrincipal ventanaPrincipal, String titulo, Boolean modal) {
		super(ventanaPrincipal, titulo, modal);
		this.setSize(screenSize);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setLocationRelativeTo(null);
		
		imgIcon = new ImageIcon(getClass().getResource("/resources/pochita.jpg")).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
		
		this.setIconImage(imgIcon);
		this.add(ptd, BorderLayout.NORTH);
		vBox.add(pdp);
		vBox.add(pdh);
		vBox.add(pi);
		this.add(vBox);
		this.setVisible(false);
	}
}

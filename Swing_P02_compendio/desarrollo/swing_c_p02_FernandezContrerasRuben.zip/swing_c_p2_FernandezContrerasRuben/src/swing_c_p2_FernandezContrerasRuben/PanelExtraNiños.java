/**
 * PanelExtraNiños.java
 * 17 nov 2024 18:11:34
 * @author Rubén Fernández Contreras
 */
package swing_c_p2_FernandezContrerasRuben;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

// TODO: Auto-generated Javadoc
/**
 * The Class PanelExtraNiños.
 */
public class PanelExtraNiños extends JPanel {
	
	/** The js edad ninios. */
	JSpinner jsEdadNinios;
	
	/** The extras. */
	JTextField extras;
	
	/** The gbconstraints. */
	GridBagConstraints gbconstraints = new GridBagConstraints();


	/**
	 * Instantiates a new panel extra niños.
	 */
	public PanelExtraNiños() {
		this.setLayout(new GridBagLayout());

		gbconstraints.insets = new Insets(5, 5, 5, 5);
		gbconstraints.fill = GridBagConstraints.HORIZONTAL;
		iniciarComponentes();
		setConstrains();
		setListeners();
		this.setVisible(false);
	}

	/**
	 * Iniciar componentes.
	 */
	public void iniciarComponentes() {
		jsEdadNinios = new JSpinner();
		jsEdadNinios = new JSpinner(new SpinnerNumberModel(0, 0, 14, 1));
		jsEdadNinios.setBounds(0, 0, 100, 30);
		jsEdadNinios.setPreferredSize(new Dimension(250, 20));
		extras = new JTextField(30);
	}

	/**
	 * Sets the listeners.
	 */
	public void setListeners() {
		FocusListener valorListener = new FocusListener() {

			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void focusGained(FocusEvent e) {
				int valor = (int) jsEdadNinios.getValue();
				if (valor >= 0 && valor <= 3) {
					extras.setText("Cuna");
				} else if (valor >= 4 && valor <= 10) {
					extras.setText("Cama supletoria pequeña");
				} else if (valor >= 11 && valor <= 14) {
					extras.setText("Cama supletoria normal");
				}
			}
		};
		extras.addFocusListener(valorListener);
		jsEdadNinios.addFocusListener(valorListener);
	}
	
	/**
	 * Sets the constrains.
	 */
	public void setConstrains() {
		gbconstraints.gridx = 0;
		gbconstraints.gridy = 0;
		this.add(jsEdadNinios, gbconstraints);

		gbconstraints.gridx = 1;
		gbconstraints.gridy = 0;
		this.add(extras, gbconstraints);

//		gbconstraints.gridx = 0;
//		gbconstraints.gridy = 1;
//		this.add(jsNumHabitaciones, gbconstraints);
//
//		gbconstraints.gridx = 1;
//		gbconstraints.gridy = 1;
//		this.add(chbNinios, gbconstraints);
//
//		gbconstraints.gridx = 0;
//		gbconstraints.gridy = 2;
//		this.add(pen, gbconstraints);
//
//		gbconstraints.gridx = 1;
//		gbconstraints.gridy = 2;
//		this.add(tfDNI, gbconstraints);
//
//		gbconstraints.gridx = 2;
//		gbconstraints.gridy = 2;
//		this.add(lbCorrectoDNI, gbconstraints);
//
//		gbconstraints.gridx = 0;
//		gbconstraints.gridy = 3;
//		this.add(lbTelefono, gbconstraints);
//
//		gbconstraints.gridx = 1;
//		gbconstraints.gridy = 3;
//		this.add(tfTelefono, gbconstraints);
//
//		gbconstraints.gridx = 2;
//		gbconstraints.gridy = 3;
//		this.add(lbCorrectoTelefono, gbconstraints);
//
//		gbconstraints.gridx = 1;
//		gbconstraints.gridy = 5;
//		this.add(lbFechaEntrada, gbconstraints);
//
//		gbconstraints.gridx = 1;
//		gbconstraints.gridy = 6;
//		this.add(tfFechaEntrada, gbconstraints);
//
//		gbconstraints.gridx = 2;
//		gbconstraints.gridy = 5;
//		this.add(lbFechaSalida, gbconstraints);
//
//		gbconstraints.gridx = 2;
//		gbconstraints.gridy = 6;
//		this.add(tfFechaSalida, gbconstraints);
//
//		gbconstraints.gridx = 0;
//		gbconstraints.gridy = 7;
//		this.add(lbDiasInstancia, gbconstraints);
//
//		gbconstraints.gridx = 1;
//		gbconstraints.gridy = 7;
//		gbconstraints.gridwidth = 2;
//		this.add(tfDiasInstancia, gbconstraints);

//		gbconstraints.gridwidth = 2; // Ocupa las dos columnas
//		gbconstraints.anchor = GridBagConstraints.CENTER;
	}

}

/**
 * MainClass.java
 * 16 nov 2024 11:54:26
 * @author Rubén Fernández Contreras
 */
package swing_c_p2_FernandezContrerasRuben;

// TODO: Auto-generated Javadoc
/**
 * The Class MainClass.
 */
public class MainClass {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		VentanaPrincipal ventana = new VentanaPrincipal();

	}

}

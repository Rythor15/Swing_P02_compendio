/**
 * VentanaPrincipal.java
 * 16 nov 2024 11:54:44
 * @author Rubén Fernández Contreras
 */
package swing_c_p2_FernandezContrerasRuben;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.KeyStroke;

// TODO: Auto-generated Javadoc
/**
 * The Class VentanaPrincipal.
 */
public class VentanaPrincipal extends JFrame {

	/** The t. */
	Toolkit t = Toolkit.getDefaultToolkit();
	
	/** The screen size. */
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	
	/** The ptfl. */
	PanelTitulo ptfl = new PanelTitulo();
	
	/** The flbtn. */
	JPanel flbtn = new JPanel(new FlowLayout(FlowLayout.RIGHT));
	
	/** The flimg. */
	JPanel flimg = new JPanel(new FlowLayout(FlowLayout.CENTER));
	
	/** The mbmenu. */
	JMenuBar mbmenu = new JMenuBar();
	
	/** The menu ayuda. */
	JMenu menuArchivo, menuRegistro, menuAyuda;
	
	/** The lb img centro. */
	JLabel lbImgCentro;
	
	/** The mi acerca de. */
	JMenuItem miSalir, miAltaReservas, miBajaReservas, miAcercaDe;
	
	/** The img centro. */
	Image imgIcon, imgNuevo, imgEliminar, imgCentro;
	
	/** The img centro escalado. */
	ImageIcon imgNuevoEscalada, imgEliminarEscalada, imgCentroEscalado;
	
	/** The btn eliminar. */
	JButton btnNuevo, btnEliminar;
	
	/** The ventana dialogo. */
	VentanaDialogo ventanaDialogo;

	/**
	 * Instantiates a new ventana principal.
	 */
	public VentanaPrincipal() {
		super("Gestion Hotel Pochita");
		this.setSize(screenSize.width / 2, screenSize.height / 2);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		ventanaDialogo = new VentanaDialogo(this, "Alta Reservas", true);
		
		menuArchivo = new JMenu("Archivo");
		menuRegistro = new JMenu("Registro");
		menuAyuda = new JMenu("Ayuda");

		miSalir = new JMenuItem("Salir");
		miAcercaDe = new JMenuItem("Acerca de...");
		miAltaReservas = new JMenuItem("Alta Reservas");
		miBajaReservas = new JMenuItem("Baja Reservas");

		menuRegistro.setMnemonic(KeyEvent.VK_ALT);
		menuRegistro.setMnemonic('r');

		miAltaReservas.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, KeyEvent.CTRL_DOWN_MASK));
		miBajaReservas.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B, KeyEvent.CTRL_DOWN_MASK));

		menuArchivo.add(miSalir);
		menuRegistro.add(miAltaReservas);
		menuRegistro.add(miBajaReservas);
		menuAyuda.add(miAcercaDe);

		mbmenu.add(menuArchivo);
		mbmenu.add(menuRegistro);
		mbmenu.add(menuAyuda);

		imgCentro = new ImageIcon(getClass().getResource("/resources/pochita.jpg")).getImage().getScaledInstance(350, 350, Image.SCALE_SMOOTH);
		imgIcon = new ImageIcon(getClass().getResource("/resources/pochita.jpg")).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
		imgNuevo = new ImageIcon(getClass().getResource("/resources/mas.png")).getImage().getScaledInstance(25, 20, Image.SCALE_SMOOTH);
		imgEliminar = new ImageIcon(getClass().getResource("/resources/menos.png")).getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
		
		imgNuevoEscalada = new ImageIcon(imgNuevo);
		imgEliminarEscalada = new ImageIcon(imgEliminar);
		
		btnNuevo = new JButton("Nuevo", imgNuevoEscalada);
		btnEliminar = new JButton("Eliminar", imgEliminarEscalada);
		
		flbtn.add(btnNuevo);
		flbtn.add(btnEliminar);
		
		imgCentroEscalado = new ImageIcon(imgCentro);
		lbImgCentro = new JLabel(imgCentroEscalado);
		
		
		
		setListeners();
		flimg.add(lbImgCentro);
		this.setIconImage(imgIcon);
		this.setJMenuBar(mbmenu);
		this.add(ptfl, BorderLayout.NORTH);
		this.add(flimg, BorderLayout.CENTER);
		this.add(flbtn, BorderLayout.SOUTH);
		this.setVisible(true);
	}

	/**
	 * Sets the listeners.
	 */
	public void setListeners() {
		miSalir.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});

		miAltaReservas.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				  ventanaDialogo.setVisible(true);
			}
		});
		miBajaReservas.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(ptfl, "Esta función no esta desarrollada todavía.");

			}
		});
		miAcercaDe.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(ptfl, String.format(
						"Esta aplicación esta hecha con el fin de ayudar a la gestión de bajas y altas en el Hotel Pochita. \n"
								+ "Gracias a la practica interfaz se pueden recoger todos los datos necesarios para la reserva de habitaciones."));

			}
		});
		btnNuevo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ventanaDialogo.setVisible(true);

			}
		});
		btnEliminar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(ptfl, "Esta función no esta desarrollada todavía.");

			}
		});
	}

}

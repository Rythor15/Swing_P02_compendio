/**
 * PanelDatosHabitacion.java
 * 16 nov 2024 17:23:40
 * @author Rubén Fernández Contreras
 */
package swing_c_p2_FernandezContrerasRuben;

import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

// TODO: Auto-generated Javadoc
/**
 * The Class PanelDatosHabitacion.
 */
public class PanelDatosHabitacion extends JPanel {
	
	/** Constraints */
	GridBagConstraints gbconstraints = new GridBagConstraints();
	
	/** Array para comboBox */
	String[] habitaciones = { "-- Selccione una --", "Simple", "Doble", "Suite" };
	
	/** ComboBox */
	JComboBox<String> cbHabitacion;
	
	/** label */
	JLabel lbHabitacion;
	
	/** Spinner. */
	JSpinner jsNumHabitaciones;
	
	/** The chb ninios. */
	JCheckBox chbNinios;
	
	/** The tfimporte habitacion. */
	JTextField tfimporteHabitacion;
	
	/** The pen. */
	PanelExtraNiños pen = new PanelExtraNiños();
	
	/** The lbimg suite. */
	JLabel lbImporte, lbimgSimple, lbimgDoble, lbimgSuite;
	
	/** The flimg. */
	JPanel flimg = new JPanel(new FlowLayout(FlowLayout.CENTER));
	
	/** The img suite. */
	ImageIcon imgSimple, imgDoble, imgSuite;
	
	/** The pdp. */
	PanelDatosPersonales pdp = new PanelDatosPersonales();

	/**
	 * Instantiates a new panel datos habitacion.
	 */
	public PanelDatosHabitacion() {
		this.setLayout(new GridBagLayout());
		this.setBackground(new Color(93,169,227));
		this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		gbconstraints.insets = new Insets(5, 5, 5, 5);
		gbconstraints.fill = GridBagConstraints.HORIZONTAL;
		
		iniciarComponentes();
		setConstrains();
		setListeners();
		this.setVisible(true);
	}

	/**
	 * Sets the listeners.
	 */
	private void setListeners() {
		chbNinios.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (chbNinios.isSelected()) {
					pen.setVisible(true);
				} else {
					pen.setVisible(false);
				}
			}
		});
		
		/*tfimporteHabitacion.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				int valorHabitacion = precioHabitacion(0);
				int precioDias = (Integer.parseInt(pdp.tfDiasInstancia.getText()) * valorHabitacion);
				int precioNinios = 20;
				
				int precioFinal = precioNinios + precioDias;
				tfimporteHabitacion.setText(String.valueOf(precioFinal));
				
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
		});*/

	}
	
	/**
	 * Precio habitacion.
	 *
	 * @param valor the valor
	 * @return the int
	 */
	public int precioHabitacion(int valor) {
		for (int i = 1; i < habitaciones.length; i++) {
			if (i == 1) {
				valor = 50;
			} else if(i == 2) {
				valor = 75;
			} else if (i == 3){
				valor = 125;
			}
		}
		return valor;
	}

	/**
	 * Iniciar componentes.
	 */
	public void iniciarComponentes() {
		lbHabitacion = new JLabel("Tipo de Habitación:");
		cbHabitacion = new JComboBox<>(habitaciones);
		tfimporteHabitacion = new JTextField();
		jsNumHabitaciones = new JSpinner();
		jsNumHabitaciones = new JSpinner(new SpinnerNumberModel(0, 0, 50, 1));
		jsNumHabitaciones.setBounds(0, 0, 100, 30);
		jsNumHabitaciones.setPreferredSize(new Dimension(250, 20));
		tfimporteHabitacion.setEditable(false);
		chbNinios = new JCheckBox("Niños?");
		chbNinios.setSelected(false);
		imgSimple = new ImageIcon(new ImageIcon(getClass().getResource("/resources/simple.jpg")).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH));
		imgDoble = new ImageIcon(new ImageIcon(getClass().getResource("/resources/doble.jpg")).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH));
		imgSuite = new ImageIcon(new ImageIcon(getClass().getResource("/resources/suite.jpg")).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH));
	
		lbimgSimple = new JLabel(imgSimple);
		lbimgDoble = new JLabel(imgDoble);
		lbimgSuite = new JLabel(imgSuite);
		
		flimg.add(lbimgSimple);
		flimg.add(lbimgDoble);
		flimg.add(lbimgSuite);
	}

	/**
	 * Sets the constrains.
	 */
	public void setConstrains() {
		gbconstraints.gridx = 0;
		gbconstraints.gridy = 0;
		this.add(lbHabitacion, gbconstraints);

		gbconstraints.gridx = 1;
		gbconstraints.gridy = 0;
		this.add(cbHabitacion, gbconstraints);

		gbconstraints.gridx = 0;
		gbconstraints.gridy = 1;
		this.add(jsNumHabitaciones, gbconstraints);

		gbconstraints.gridx = 1;
		gbconstraints.gridy = 1;
		this.add(chbNinios, gbconstraints);

		gbconstraints.gridx = 0;
		gbconstraints.gridy = 2;
		this.add(pen, gbconstraints);

		gbconstraints.gridx = 0;
		gbconstraints.gridy = 3;
		this.add(tfimporteHabitacion, gbconstraints);

		gbconstraints.gridx = 0;
		gbconstraints.gridy = 4;
		this.add(flimg, gbconstraints);
	}
}

/**
 * PanelDatosPersonales.java
 * 16 nov 2024 17:23:58
 * @author Rubén Fernández Contreras
 */
package swing_c_p2_FernandezContrerasRuben;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

// TODO: Auto-generated Javadoc
/**
 * The Class PanelDatosPersonales.
 */
public class PanelDatosPersonales extends JPanel {
	
	/** The gbconstraints. */
	GridBagConstraints gbconstraints = new GridBagConstraints();
	
	/** The lb dias instancia. */
	JLabel lbNombre, lbApellidos, lbDNI, lbTelefono, lbCorrectoTelefono, lbCorrectoDNI, lbFechaEntrada, lbFechaSalida,
			lbDiasInstancia;
	
	/** The tf dias instancia. */
	JTextField tfNombre, tfApellidos, tfDNI, tfTelefono, tfFechaEntrada, tfFechaSalida, tfDiasInstancia;
	
	/** The formato fecha. */
	DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	
	/** The fecha entrada. */
	String fechaEntrada = LocalDate.now().format(formatoFecha);
	
	/** The fecha salida. */
	String fechaSalida = LocalDate.now().plusDays(1L).format(formatoFecha);

	/**
	 * Instantiates a new panel datos personales.
	 */
	public PanelDatosPersonales() {
		this.setLayout(new GridBagLayout());
		
		gbconstraints.insets = new Insets(5, 5, 5, 5);
		gbconstraints.fill = GridBagConstraints.HORIZONTAL;
		iniciarComponentes();
		setConstrains();
		setListeners();
		this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		this.setBackground(new Color(122,210,250));
		this.setVisible(true);
	}

	/**
	 * Sets the listeners.
	 */
	public void setListeners() {
		tfTelefono.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				if (tfTelefono.getText().matches("\\d{9}")) {
					lbCorrectoTelefono.setText("Teléfono Correcto");
				} else {
					lbCorrectoTelefono.setText("Se requiere 9 números para el teléfono.");
				}

			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub

			}
		});

		tfDNI.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				if (tfDNI.getText().toUpperCase().matches("\\d{8}[A-Z]")) {
					lbCorrectoDNI.setText("Formato del DNI Correcto");
				} else {
					lbCorrectoDNI.setText("Se requiere 8 números y una letra al final para el Dni.");
				}

			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub

			}
		});

		ActionListener diasIntanciados = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String salida = tfFechaSalida.getText().trim();
				String entrada = tfFechaEntrada.getText().trim();
				LocalDate fechaSalida = LocalDate.parse(salida, formatoFecha);
				LocalDate fechaEntrada = LocalDate.parse(entrada, formatoFecha);
				long dias = ChronoUnit.DAYS.between(fechaEntrada, fechaSalida);
				tfDiasInstancia.setText(String.format(String.valueOf(dias), " dias"));
			}
		};

		tfFechaEntrada.addActionListener(diasIntanciados);
		tfFechaSalida.addActionListener(diasIntanciados);
	}

	/**
	 * Iniciar componentes.
	 */
	public void iniciarComponentes() {
		lbNombre = new JLabel("Nombre:");
		lbApellidos = new JLabel("Apellido:");
		lbDNI = new JLabel("DNI:");
		lbTelefono = new JLabel("Telefono:");
		lbCorrectoTelefono = new JLabel();
		lbCorrectoDNI = new JLabel();
		lbDiasInstancia = new JLabel("Dias Instanciados: ");
		lbFechaEntrada = new JLabel("Fecha de entrada: ");
		lbFechaSalida = new JLabel("Fecha de salida: ");
		tfNombre = new JTextField(15);
		tfApellidos = new JTextField(30);
		tfDNI = new JTextField(10);
		tfTelefono = new JTextField(10);
		tfFechaEntrada = new JTextField(fechaEntrada);
		tfFechaSalida = new JTextField(fechaSalida);
		tfDiasInstancia = new JTextField(20);
		tfDiasInstancia.setEditable(false);
	}

	/**
	 * Sets the constrains.
	 */
	public void setConstrains() {
		gbconstraints.gridx = 0;
		gbconstraints.gridy = 0;
		this.add(lbNombre, gbconstraints);

		gbconstraints.gridx = 1;
		gbconstraints.gridy = 0;
		this.add(tfNombre, gbconstraints);

		gbconstraints.gridx = 0;
		gbconstraints.gridy = 1;
		this.add(lbApellidos, gbconstraints);

		gbconstraints.gridx = 1;
		gbconstraints.gridy = 1;
		this.add(tfApellidos, gbconstraints);

		gbconstraints.gridx = 0;
		gbconstraints.gridy = 2;
		this.add(lbDNI, gbconstraints);

		gbconstraints.gridx = 1;
		gbconstraints.gridy = 2;
		this.add(tfDNI, gbconstraints);

		gbconstraints.gridx = 2;
		gbconstraints.gridy = 2;
		this.add(lbCorrectoDNI, gbconstraints);

		gbconstraints.gridx = 0;
		gbconstraints.gridy = 3;
		this.add(lbTelefono, gbconstraints);

		gbconstraints.gridx = 1;
		gbconstraints.gridy = 3;
		this.add(tfTelefono, gbconstraints);

		gbconstraints.gridx = 2;
		gbconstraints.gridy = 3;
		this.add(lbCorrectoTelefono, gbconstraints);

		gbconstraints.gridx = 1;
		gbconstraints.gridy = 5;
		this.add(lbFechaEntrada, gbconstraints);

		gbconstraints.gridx = 1;
		gbconstraints.gridy = 6;
		this.add(tfFechaEntrada, gbconstraints);

		gbconstraints.gridx = 2;
		gbconstraints.gridy = 5;
		this.add(lbFechaSalida, gbconstraints);

		gbconstraints.gridx = 2;
		gbconstraints.gridy = 6;
		this.add(tfFechaSalida, gbconstraints);

		gbconstraints.gridx = 0;
		gbconstraints.gridy = 7;
		this.add(lbDiasInstancia, gbconstraints);

		gbconstraints.gridx = 1;
		gbconstraints.gridy = 7;
		gbconstraints.gridwidth = 2;
		this.add(tfDiasInstancia, gbconstraints);

	}

}

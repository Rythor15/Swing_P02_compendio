/**
 * PanelTitulo.java
 * 16 nov 2024 12:04:55
 * @author Rubén Fernández Contreras
 */
package swing_c_p2_FernandezContrerasRuben;

import java.awt.FlowLayout;
import java.awt.Panel;

import javax.swing.JLabel;
import javax.swing.JPanel;

// TODO: Auto-generated Javadoc
/**
 * The Class PanelTitulo.
 */
public class PanelTitulo extends JPanel{
		
	/**
	 * Instantiates a new panel titulo.
	 */
	public PanelTitulo() {
		JLabel lbtitulo = new JLabel("Gestión Hotel Pochita");
		
		this.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.add(lbtitulo);
		
	}
}

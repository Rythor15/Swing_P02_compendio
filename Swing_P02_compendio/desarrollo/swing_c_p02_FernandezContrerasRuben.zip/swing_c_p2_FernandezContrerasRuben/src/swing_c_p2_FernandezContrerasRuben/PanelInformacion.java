/**
 * PanelInformacion.java
 * 17 nov 2024 21:43:56
 * @author Rubén Fernández Contreras
 */
package swing_c_p2_FernandezContrerasRuben;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

// TODO: Auto-generated Javadoc
/**
 * The Class PanelInformacion.
 */
public class PanelInformacion extends JTabbedPane {
	
	/** Paneles. */
	private JPanel pCliente, pReserva;
	
	/** Los labels */
	private JLabel lbCliente, lbReserva;
	
	/** Los textfield. */
	static JTextArea tfCliente, tfReserva;

	/**
	 * Instantiates a new panel informacion.
	 */
	public PanelInformacion() {

		

		informacionCliente();
		informacionAlojamiento();

		this.add("Datos del Cliente", pCliente);
		this.add("Datos de la reserva", pReserva);
		
		pCliente.setBackground(new Color(3, 252, 244));
		pReserva.setBackground(new Color(3, 103, 252));
	}

	/**
	 * Informacion cliente.
	 */
	private void informacionCliente() {

		pCliente = new JPanel();

		lbCliente = new JLabel("Datos del Cliente: ");

		tfCliente = new JTextArea(100, 100);
		tfCliente.setEditable(false);

		pCliente.add(lbCliente);
		pCliente.add(tfCliente);
		this.add(pCliente);
	}

	/**
	 * Informacion alojamiento.
	 */
	private void informacionAlojamiento() {

		pReserva = new JPanel();

		lbReserva = new JLabel("Datos del Alojamiento:");

		tfReserva = new JTextArea(100, 100);
		tfReserva.setEditable(false);

		pReserva.add(lbReserva);
		pReserva.add(tfReserva);
		this.add(pReserva);
	}
}

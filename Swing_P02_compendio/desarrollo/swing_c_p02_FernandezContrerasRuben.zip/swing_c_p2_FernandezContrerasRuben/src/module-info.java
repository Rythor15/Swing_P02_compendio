module swing_c_p2_FernandezContrerasRuben {
	requires java.desktop;
}